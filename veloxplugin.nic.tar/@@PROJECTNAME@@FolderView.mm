#import "VeloxFolderViewProtocol.h"
/*Velox Folder Pugin*/


@interface @@PROJECTNAME@@FolderView : UIView <VeloxFolderViewProtocol>
//Add properties, iVars here
@end

@implementation @@PROJECTNAME@@FolderView

-(UIView *)initWithFrame:(CGRect)aFrame{
	self = [super initWithFrame:aFrame];
    if (self){
		//Add subviews, load data, etc.
	}
    return self;
}


+(int)folderHeight{
	return 100; //Make folder bigger on i5 devices?
}
@end